using Cloiuw.Application.Helpers;
using Cloiuw.Application.Interface.Repository;
using Cloiuw.Application.Model.Corretor;
using Cloiuw.Application.Model.Imovel;
using Cloiuw.Repository.Scripts;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Cloiuw.Repository.Repositories
{
    public class CorretoresRepository : ICorretoresRepository
    {
        protected readonly DbCloiuwSessionFactory db;

        public CorretoresRepository(DbCloiuwSessionFactory db)
        {
            this.db = db;
        }

        public async Task<CorretorGetModel> ListarInformacoes(Guid idCorretor)
        {
            DynamicParameters parameters = new();
            parameters.Add("@id_corretor", idCorretor, DbType.Guid);

            // Passei o [ImovelCorretorGetModel] entretanto, n�o temos um modelo dele. Acredito que iremos precisar desta conex�o
            // para saber o imovel que o corretor cadastrou, m�s n�o sei se aqui � o lugar ideal. 

            var result = await db.IsolatedSession.QueryAsync<CorretorGetModel, IEnumerable<string>, IEnumerable<ImovelCorretorGetModel>, CorretorGetModel>(
                ScriptDeCorretor.ListarInformacoes,
                (corretor, telefones, imoveis) =>
                {
                    corretor.Telefones = telefones;
                    corretor.Imoveis = imoveis;

                    return corretor;
                }, parameters);

            return result.FirstOrDefault();
        }

        public async Task<bool> CorretorCadastrado(Guid idCorretor)
        {
            DynamicParameters parameters = new();
            parameters.Add("@id_corretor", idCorretor, DbType.Guid);

            int count = await db.IsolatedSession.QueryFirstOrDefaultAsync<int>(ScriptDeCorretor.ExisteCorretor, parameters);

            return count > 0;
        }
    }
}
