using Cloiuw.Application.Helpers;
using Cloiuw.Application.Interface.Repository;
using Cloiuw.Application.Model.Imobiliaria;
using Cloiuw.Application.Model.Imovel;
using Cloiuw.Repository.Scripts;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Cloiuw.Repository.Repositories
{
    public class ImobiliariaRepository : IImobiliariaRepository
    {
        protected readonly DbCloiuwSessionFactory db;

        public ImobiliariaRepository(DbCloiuwSessionFactory db)
        {
            this.db = db;
        }

        public async Task<ImobiliariaGetModel> ListarInformacoes(Guid idImobiliaria)
        {
            DynamicParameters parameters = new();
            parameters.Add("@id_imobiliaria", idImobiliaria, DbType.Guid);

            var result = await db.IsolatedSession.QueryAsync<ImobiliariaGetModel, IEnumerable<string>, IEnumerable<ImovelImobiliariaGetModel>, ImobiliariaGetModel>(
                ScriptDeImobiliaria.ListarInformacoes,
                (imobiliaria, telefones, imoveis) =>
                {
                    imobiliaria.Telefones = telefones;
                    imobiliaria.Imoveis = imoveis;

                    return imobiliaria;
                }, parameters);

            return result.FirstOrDefault();
        }

        public async Task<bool> ImobiliariaCadastrada(Guid idImobiliaria)
        {
            DynamicParameters parameters = new();
            parameters.Add("@id_imobiliaria", idImobiliaria, DbType.Guid);

            int count = await db.IsolatedSession.QueryFirstOrDefaultAsync<int>(ScriptDeImobiliaria.ExisteImobiliaria, parameters);

            return count > 0;
        }
    }
}
