using Cloiuw.Application.Helpers;
using Cloiuw.Application.Interface.Repository;
using Cloiuw.Application.Model.Imovel;
using Cloiuw.Application.Model.ImoveisProprietarios;
using Cloiuw.Repository.Scripts;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Cloiuw.Repository.Repositories
{
    public class ImoveisProprietariosRepository : IImoveisProprietariosRepository
    {
        protected readonly DbCloiuwSessionFactory db;

        public ImoveisProprietariosRepository(DbCloiuwSessionFactory db)
        {
            this.db = db;
        }

        public async Task<ImoveisProprietariosGetModel> ListarInformacoes(Guid idImoveisProprietarios)
        {
            DynamicParameters parameters = new();
            parameters.Add("@id_imoveis_proprietarios", idImoveisProprietarios, DbType.Guid);

            var result = await db.IsolatedSession.QueryAsync<ImoveisProprietariosGetModel, IEnumerable<ImovelProprietarioGetModel>, ImoveisProprietariosGetModel>(
                ScriptDeImoveisProprietarios.ListarInformacoes,
                (imoveisProprietarios, imoveis) =>
                {
                    imoveisProprietarios.Imoveis = imoveis;

                    return imoveisProprietarios;
                }, parameters);

            return result.FirstOrDefault();
        }

        public async Task<bool> ImoveisProprietariosCadastrado(Guid idImoveisProprietarios)
        {
            DynamicParameters parameters = new();
            parameters.Add("@id_imoveis_proprietarios", idImoveisProprietarios, DbType.Guid);

            int count = await db.IsolatedSession.QueryFirstOrDefaultAsync<int>(ScriptDeImoveisProprietarios.ExisteImoveisProprietarios, parameters);

            return count > 0;
        }
    }
}
