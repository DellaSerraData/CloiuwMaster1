using Cloiuw.Application.Helpers;
using Cloiuw.Application.Interface.Repository;
using Cloiuw.Application.Model.Imovel;
using Cloiuw.Application.Model.Locadores;
using Cloiuw.Repository.Scripts;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Cloiuw.Repository.Repositories
{
    public class LocadoresRepository : ILocadoresRepository
    {
        protected readonly DbCloiuwSessionFactory db;

        public LocadoresRepository(DbCloiuwSessionFactory db)
        {
            this.db = db;
        }

        public async Task<LocadoresGetModel> ListarInformacoes(Guid idLocador)
        {
            DynamicParameters parameters = new();
            parameters.Add("@id_locador", idLocador, DbType.Guid);

            var result = await db.IsolatedSession.QueryAsync<LocadoresGetModel, IEnumerable<string>, IEnumerable<ImovelLocadorGetModel>, LocadoresGetModel>(
                ScriptDeLocadores.ListarInformacoes,
                (locador, telefones, imoveis) =>
                {
                    locador.Telefones = telefones;
                    locador.Imoveis = imoveis;

                    return locador;
                }, parameters);

            return result.FirstOrDefault();
        }

        public async Task<bool> LocadorCadastrado(Guid idLocador)
        {
            DynamicParameters parameters = new();
            parameters.Add("@id_locador", idLocador, DbType.Guid);

            int count = await db.IsolatedSession.QueryFirstOrDefaultAsync<int>(ScriptDeLocadores.ExisteLocador, parameters);

            return count > 0;
        }
    }
}
