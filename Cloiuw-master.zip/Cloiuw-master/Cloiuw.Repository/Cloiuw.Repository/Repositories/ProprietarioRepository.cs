﻿using Cloiuw.Application.Helpers;
using Cloiuw.Application.Interface.Repository;
using Cloiuw.Application.Model.Imovel;
using Cloiuw.Application.Model.Proprietario;
using Cloiuw.Repository.Scripts;
using Dapper;
using System.Data;

namespace Cloiuw.Repository.Repositories
{
    public class ProprietarioRepository : IProprietarioRepository
    {
        protected readonly DbCloiuwSessionFactory db;
        public ProprietarioRepository(DbCloiuwSessionFactory db)
        {
            this.db = db;
        }
        public async Task<ProprietarioGetModel> ListarInformacoes(Guid idProprietario)
        {
            DynamicParameters parameters = new();
            parameters.Add("@id_proprietario", idProprietario, DbType.Guid);

            var result = await db.IsolatedSession.QueryAsync<ProprietarioGetModel, IEnumerable<string>, IEnumerable<ImovelProprietarioGetModel>, ProprietarioGetModel>
                                                            (ScriptDeProprietario.ListarInformacoes,
                                                            (proprietario, telefones, imoveis) =>
                                                            {
                                                                proprietario.Telefones = telefones;
                                                                proprietario.Imoveis = imoveis;

                                                                return proprietario;
                                                            }, parameters);
            return result.FirstOrDefault();
        }

        public async Task<bool> ProprietarioCadastrado(Guid idProprietario)
        {
            DynamicParameters parameters = new();
            parameters.Add("@id_proprietario", idProprietario, DbType.Guid);

            int count = await db.IsolatedSession.QueryFirstOrDefaultAsync<int>(ScriptDeProprietario.ExisteProprietario, parameters);

            return count > 0;
        }
    }
}
