namespace Cloiuw.Repository.Scripts
{
    public static class ScriptDeImobiliaria
    {
        public const string ExisteImobiliaria = @"SELECT 
                                                    COUNT(id_imobiliaria)
                                               FROM imobiliaria
                                               WHERE id_imobiliaria = @id_imobiliaria";

        public const string ListarInformacoes = @"SELECT
                                                    i.id_imobiliaria AS IdImobiliaria,
                                                    i.nome,
                                                    i.cnpj,
                                                    i.email,
                                                    i.data_cadastro AS DataCadastro,
                                                    i.data_ultima_modificacao AS DataUltimaModificacao
                                                FROM imobiliaria i
                                                WHERE i.id_imobiliaria = @id_imobiliaria";
    }
}
