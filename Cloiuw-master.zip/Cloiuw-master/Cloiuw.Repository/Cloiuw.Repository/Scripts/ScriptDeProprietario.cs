﻿namespace Cloiuw.Repository.Scripts
{
    public static class ScriptDeProprietario
    {
        public const string ExisteProprietario = @"SELECT 
                                                    COUNT(id_proprietario)
                                                   FROM proprietario
                                                   WHERE id_proprietario = @id_proprietario";

        public const string ListarInformacoes = @"SELECT
                                                    p.id_proprietario AS IdProprietario,
                                                    p.nome,
                                                    p.sobrenome,
                                                    p.cpf,
                                                    p.email,
                                                    CONCAT(c.ddd, c.numero) AS Telefones,
                                                    i.id,
                                                    i.endereco,
                                                    i.complemento,
                                                    i.estado,
                                                    i.cidade,
                                                    i.bairro,
                                                    i.pais,
                                                    i.area_total AS AreaTotal,
                                                    i.area_construida AS AreaConstruida,
                                                    i.valor_aluguel AS ValorAluguel,
                                                    i.valor_venda AS ValorVenda,
                                                    i.valor_condominio AS ValorCondominio,
                                                    i.valor_iptu AS ValorIptu,
                                                    i.quantidade_quartos AS QuantidadeQuartos,
                                                    i.quantidade_banheiros AS QuantidadeBanheiros,
                                                    i.quantidade_vagas AS QuantidadeVagas,
                                                    i.mobiliado,
                                                    i.aceita_animais as AceitaAnimais
                                                FROM proprietario p
                                                    INNER JOIN imovel i ON p.id_proprietario = i.id_proprietario
                                                    INNER JOIN contato c ON p.id_proprietario = c.id_proprietario
                                                WHERE p.id_proprietario = @id_proprietario";
    }
}
