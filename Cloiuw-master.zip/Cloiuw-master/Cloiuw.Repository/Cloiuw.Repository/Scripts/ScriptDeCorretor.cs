namespace Cloiuw.Repository.Scripts
{
    public static class ScriptDeCorretor
    {
        public const string ExisteCorretor = @"SELECT 
                                                    COUNT(id_corretor)
                                               FROM corretor
                                               WHERE id_corretor = @id_corretor";

        public const string ListarInformacoes = @"SELECT
                                                    c.id_corretor AS IdCorretor,
                                                    c.nome,
                                                    c.sobrenome,
                                                    c.cpf,
                                                    c.email,
                                                    c.data_nascimento AS DataNascimento,
                                                    c.data_cadastro AS DataCadastro,
                                                    c.data_ultima_modificacao AS DataUltimaModificacao
                                                FROM corretor c
                                                WHERE c.id_corretor = @id_corretor";
    }
}
