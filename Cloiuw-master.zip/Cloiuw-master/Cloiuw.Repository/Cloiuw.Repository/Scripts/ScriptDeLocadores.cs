namespace Cloiuw.Repository.Scripts
{
    public static class ScriptDeLocadores
    {
        public const string ExisteLocador = @"SELECT 
                                                    COUNT(id_locador)
                                               FROM locador
                                               WHERE id_locador = @id_locador";

        public const string ListarInformacoes = @"SELECT
                                                    l.id_locador AS IdLocador,
                                                    l.nome,
                                                    l.sobrenome,
                                                    l.cpf,
                                                    l.email,
                                                    l.data_nascimento AS DataNascimento,
                                                    l.data_cadastro AS DataCadastro,
                                                    l.data_ultima_modificacao AS DataUltimaModificacao
                                                FROM locador l
                                                WHERE l.id_locador = @id_locador";
    }
}
