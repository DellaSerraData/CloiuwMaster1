﻿using Cloiuw.Application.Configs;
using Cloiuw.Application.Helpers;
using Cloiuw.Application.Interface.Repository;
using Cloiuw.Application.Interface.Service;
using Cloiuw.Application.Service;
using Cloiuw.Repository.Repositories;
using Microsoft.Extensions.DependencyInjection;

namespace Cloiuw.CrossCutting.IOC
{
    public static class DependencyResolver
    {
        public static void AddDependencyResolver(this IServiceCollection services) 
        {
            LoadParameters(services);
            RegisterServices(services);
            RegisterDomain(services);
            RegisterRepository(services);
        }

        public static void LoadParameters(IServiceCollection services)
        {
            DbCloiuwConfig.DbCloiuwConnectionString = string.Format(Environment.GetEnvironmentVariable("DbCloiuw"),
                Environment.GetEnvironmentVariable("DbCloiuw_USER"), Environment.GetEnvironmentVariable("DbCloiuw_PWD"));
            
            DbCloiuwConfig dbCloiuw = new();
            services.AddSingleton(dbCloiuw);
            services.AddSingleton<DbCloiuwSessionFactory>(x => new DbCloiuwSessionFactory());
        }
        public static void RegisterServices(IServiceCollection services)
        {
            services.AddSingleton<IProprietarioService, ProprietarioService>();
        }

        public static void RegisterDomain(IServiceCollection services)
        {

        }

        public static void RegisterRepository(IServiceCollection services)
        {
            services.AddSingleton<IProprietarioRepository, ProprietarioRepository>();
        }
    }
}
