﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cloiuw.CrossCutting.Extension
{
    public static class HttpContextExtensions
    {
        public static IApplicationBuilder UseHttpContext(this IApplicationBuilder app)
        {
            MyHttpContext.Configure(app.ApplicationServices.GetRequiredService<IHttpContextAccessor>());
            return app;
        }

        public static class MyHttpContext
        {
            private static IHttpContextAccessor myHttpContextAccessor;
            public static HttpContext Current => myHttpContextAccessor?.HttpContext;
            public static string AppBaseUrl => $"{Current?.Request?.Scheme}://{Current?.Request?.Host}{Current?.Request?.PathBase}";

            public static void Configure(IHttpContextAccessor contextAccessor)
            {
                myHttpContextAccessor = contextAccessor;
            }
        }
    }
}
