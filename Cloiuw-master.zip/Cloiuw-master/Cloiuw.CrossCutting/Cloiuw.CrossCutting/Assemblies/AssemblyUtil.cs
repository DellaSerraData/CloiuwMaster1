﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Cloiuw.CrossCutting.Assemblies
{
    public static class AssemblyUtil
    {
        public static IEnumerable<Assembly> GetCurrentAssemblies()
        {
            return new Assembly[]
            {
                Assembly.Load("Cloiuw.Api"),
                Assembly.Load("Cloiuw.Application"),
                Assembly.Load("Cloiuw.CrossCutting"),
                Assembly.Load("Cloiuw.Domain"),
                Assembly.Load("Cloiuw.Repository")
            };
        }
    }
}
