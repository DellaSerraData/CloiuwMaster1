using Cloiuw.Application.Interface.Repository;
using Cloiuw.Application.Interface.Service;
using Cloiuw.Application.Model.Imobiliaria;
using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Cloiuw.Application.Service
{
    public class ImobiliariaService : IImobiliariaService
    {
        protected readonly IImobiliariaRepository imobiliariaRepository;

        public ImobiliariaService(IImobiliariaRepository imobiliariaRepository)
        {
            this.imobiliariaRepository = imobiliariaRepository;
        }

        public async Task<ImobiliariaGetModel> ListarInformacoes(Guid idImobiliaria)
        {
            bool existeImobiliaria = await imobiliariaRepository.ImobiliariaCadastrada(idImobiliaria);

            if (!existeImobiliaria)
                throw new ValidationException("Imobili�ria n�o cadastrada.");

            return await imobiliariaRepository.ListarInformacoes(idImobiliaria);
        }
    }
}
