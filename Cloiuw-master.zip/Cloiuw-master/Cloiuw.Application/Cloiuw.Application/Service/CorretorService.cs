using Cloiuw.Application.Interface.Repository;
using Cloiuw.Application.Interface.Service;
using Cloiuw.Application.Model.Corretor;
using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Cloiuw.Application.Service
{
    public class CorretoresService : ICorretoresService
    {
        protected readonly ICorretoresRepository corretoresRepository;

        public CorretoresService(ICorretoresRepository corretoresRepository)
        {
            this.corretoresRepository = corretoresRepository;
        }

        public async Task<CorretorGetModel> ListarInformacoes(Guid idCorretor)
        {
            bool existeCorretor = await corretoresRepository.CorretorCadastrado(idCorretor);

            if (!existeCorretor)
                throw new ValidationException("Corretor n�o cadastrado.");

            return await corretoresRepository.ListarInformacoes(idCorretor);
        }
    }
}
