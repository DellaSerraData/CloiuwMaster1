using Cloiuw.Application.Interface.Repository;
using Cloiuw.Application.Interface.Service;
using Cloiuw.Application.Model.ImoveisProprietarios;
using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Cloiuw.Application.Service
{
    public class ImoveisProprietariosService : IImoveisProprietariosService
    {
        protected readonly IImoveisProprietariosRepository imoveisProprietariosRepository;

        public ImoveisProprietariosService(IImoveisProprietariosRepository imoveisProprietariosRepository)
        {
            this.imoveisProprietariosRepository = imoveisProprietariosRepository;
        }

        public async Task<ImoveisProprietariosGetModel> ListarInformacoes(Guid idImoveisProprietarios)
        {
            bool existeImoveisProprietarios = await imoveisProprietariosRepository.ImoveisProprietariosCadastrado(idImoveisProprietarios);

            if (!existeImoveisProprietarios)
                throw new ValidationException("Im�veis dos propriet�rios n�o cadastrados.");

            return await imoveisProprietariosRepository.ListarInformacoes(idImoveisProprietarios);
        }
    }
}
