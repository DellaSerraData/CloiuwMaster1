﻿using Cloiuw.Application.Interface.Repository;
using Cloiuw.Application.Interface.Service;
using Cloiuw.Application.Model.Proprietario;
using System.ComponentModel.DataAnnotations;

namespace Cloiuw.Application.Service
{
    public class ProprietarioService : IProprietarioService
    {
        protected readonly IProprietarioRepository proprietarioRepository;
        public ProprietarioService(IProprietarioRepository proprietarioRepository)
        {

            this.proprietarioRepository = proprietarioRepository;

        }
        public async Task<ProprietarioGetModel> ListarInformacoes(Guid idProprietario)
        {
            bool existeProprietario = await proprietarioRepository.ProprietarioCadastrado(idProprietario);

            if (!existeProprietario)
                throw new ValidationException("Proprietário não cadastrado.");

            return await proprietarioRepository.ListarInformacoes(idProprietario);
        }
    }
}
