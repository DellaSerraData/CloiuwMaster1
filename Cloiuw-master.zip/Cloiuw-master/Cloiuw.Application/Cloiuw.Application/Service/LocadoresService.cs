using Cloiuw.Application.Interface.Repository;
using Cloiuw.Application.Interface.Service;
using Cloiuw.Application.Model.Locadores;
using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Cloiuw.Application.Service
{
    public class LocadoresService : ILocadoresService
    {
        protected readonly ILocadoresRepository locadoresRepository;

        public LocadoresService(ILocadoresRepository locadoresRepository)
        {
            this.locadoresRepository = locadoresRepository;
        }

        public async Task<LocadoresGetModel> ListarInformacoes(Guid idLocador)
        {
            bool existeLocador = await locadoresRepository.LocadorCadastrado(idLocador);

            if (!existeLocador)
                throw new ValidationException("Locador n�o cadastrado.");

            return await locadoresRepository.ListarInformacoes(idLocador);
        }
    }
}
