﻿using Cloiuw.Application.Configs;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Cloiuw.Application.Helpers
{
    public class DbCloiuwSessionFactory : IDisposable
    {
        private bool _disposed = false;
        ~DbCloiuwSessionFactory() => Dispose(false);

        private IDbConnection _session;
        public IDbTransaction Transaction { get; set; }
        public IDbConnection Session
        {
            get
            {
                _session ??= new SqlConnection(DbCloiuwConfig.DbCloiuwConnectionString);
                return _session;
            }
            set => _session = value;
        }

        public IDbConnection IsolatedSession => new SqlConnection(DbCloiuwConfig.DbCloiuwConnectionString);

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                if (Session.State != ConnectionState.Closed)

                {
                    Session.Close();
                }

                Transaction?.Dispose();

                Session?.Dispose();
            }
            _disposed = true;
        }
    }
}
