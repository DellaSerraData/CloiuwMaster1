using System;
using System.Collections.Generic;

namespace Cloiuw.Application.Model.Locadores
{
    public class LocadoresGetModel
    {
        public string IdLocador { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public string Cpf { get; set; }
        public string Email { get; set; }
        public IEnumerable<string> Telefones { get; set; }
        public IEnumerable<ImoveisLocadoresGetModel> Imoveis { get; set; }
        public DateTime DataNascimento { get; set; }
        public DateTime DataCadastro { get; set; }
        public DateTime DataUltimaModificacao { get; set; }
    }
}
