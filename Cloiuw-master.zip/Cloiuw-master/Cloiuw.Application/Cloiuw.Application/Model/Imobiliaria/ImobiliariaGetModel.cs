using System;
using System.Collections.Generic;

namespace Cloiuw.Application.Model.Imobiliaria
{
    public class ImobiliariaGetModel
    {
        public string IdImobiliaria { get; set; }
        public string Nome { get; set; }
        public string Cnpj { get; set; }
        public string Email { get; set; }
        public IEnumerable<string> Telefones { get; set; }
        public IEnumerable<ImoveisImobiliariaGetModel> Imoveis { get; set; }
        public DateTime DataCadastro { get; set; }
        public DateTime DataUltimaModificacao { get; set; }
    }
}
