using Cloiuw.Application.Model.Imovel;
using System;
using System.Collections.Generic;

namespace Cloiuw.Application.Model.Corretor
{
    public class CorretorGetModel
    {
        public string IdCorretor { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public string Cpf { get; set; }
        public string Email { get; set; }
        public IEnumerable<string> Telefones { get; set; }
        public IEnumerable<ImoveisCorretorGetModel> Imoveis { get; set; }
        public DateTime DataNascimento { get; set; }
        public DateTime DataCadastro { get; set; }
        public DateTime DataUltimaModificacao { get; set; }
    }
}
