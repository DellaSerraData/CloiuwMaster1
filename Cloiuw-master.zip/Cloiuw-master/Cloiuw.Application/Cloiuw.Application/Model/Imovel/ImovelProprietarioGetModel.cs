﻿namespace Cloiuw.Application.Model.Imovel
{
    public class ImovelProprietarioGetModel
    {
        public string Id { get; set; }
        public string Endereco { get; set; }
        public string Complemento{ get; set; }
        public string Estado { get; set; }
        public string Cidade { get; set; }
        public string Bairro { get; set; }
        public string Pais { get; set; }
        public decimal AreaTotal { get; set; }
        public decimal AreaConstruida { get; set; }
        public decimal ValorAluguel { get; set; }
        public decimal ValorVenda { get; set; }
        public decimal ValorCondominio { get; set; }
        public decimal ValorIptu{ get; set; }
        public int QuantidadeQuartos { get; set; }
        public int QuantidadeBanheiros { get; set; }
        public int QuantidadeVagas { get; set; }
        public bool PossuiGaragem 
        { 
            get => QuantidadeVagas > 0;
            set { PossuiGaragem = value; }
        }
        public bool Mobiliado { get; set; }
        public bool AceitaAnimais { get; set; }
    }
}
