using Cloiuw.Application.Model.Imobiliaria;
using System;
using System.Threading.Tasks;

namespace Cloiuw.Application.Interface.Service
{
    public interface IImobiliariaService
    {
        Task<ImobiliariaGetModel> ListarInformacoes(Guid idImobiliaria);
    }
}
