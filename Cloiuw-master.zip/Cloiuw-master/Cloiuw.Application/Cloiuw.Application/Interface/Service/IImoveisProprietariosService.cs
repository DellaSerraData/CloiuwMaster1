using Cloiuw.Application.Model.ImoveisProprietarios;
using System;
using System.Threading.Tasks;

namespace Cloiuw.Application.Interface.Service
{
    public interface IImoveisProprietariosService
    {
        Task<ImoveisProprietariosGetModel> ListarInformacoes(Guid idImoveisProprietarios);
    }
}
