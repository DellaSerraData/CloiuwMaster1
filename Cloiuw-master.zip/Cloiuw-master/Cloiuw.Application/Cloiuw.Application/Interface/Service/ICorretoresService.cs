using Cloiuw.Application.Model.Corretor;
using System;
using System.Threading.Tasks;

namespace Cloiuw.Application.Interface.Service
{
    public interface ICorretoresService
    {
        Task<CorretorGetModel> ListarInformacoes(Guid idCorretor);
    }
}
