using Cloiuw.Application.Model.Locadores;
using System;
using System.Threading.Tasks;

namespace Cloiuw.Application.Interface.Service
{
    public interface ILocadoresService
    {
        Task<LocadoresGetModel> ListarInformacoes(Guid idLocador);
    }
}
