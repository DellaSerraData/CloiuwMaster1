﻿using Cloiuw.Application.Model.Proprietario;

namespace Cloiuw.Application.Interface.Service
{
    public interface IProprietarioService
    {
        Task<ProprietarioGetModel> ListarInformacoes(Guid idProprietario);
    }
}
