using Cloiuw.Application.Model.Locadores;
using System;
using System.Threading.Tasks;

namespace Cloiuw.Application.Interface.Repository
{
    public interface ILocadoresRepository
    {
        Task<bool> LocadorCadastrado(Guid idLocador);
        Task<LocadoresGetModel> ListarInformacoes(Guid idLocador);
    }
}
