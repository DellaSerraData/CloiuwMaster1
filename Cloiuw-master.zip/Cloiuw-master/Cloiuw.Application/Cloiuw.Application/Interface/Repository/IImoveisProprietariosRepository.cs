using Cloiuw.Application.Model.ImoveisProprietarios;
using System;
using System.Threading.Tasks;

namespace Cloiuw.Application.Interface.Repository
{
    public interface IImoveisProprietariosRepository
    {
        Task<bool> ImoveisProprietariosCadastrado(Guid idImoveisProprietarios);
        Task<ImoveisProprietariosGetModel> ListarInformacoes(Guid idImoveisProprietarios);
    }
}
