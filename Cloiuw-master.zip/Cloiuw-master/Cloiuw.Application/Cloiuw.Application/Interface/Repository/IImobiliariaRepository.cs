using Cloiuw.Application.Model.Imobiliaria;
using System;
using System.Threading.Tasks;

namespace Cloiuw.Application.Interface.Repository
{
    public interface IImobiliariaRepository
    {
        Task<bool> ImobiliariaCadastrada(Guid idImobiliaria);
        Task<ImobiliariaGetModel> ListarInformacoes(Guid idImobiliaria);
    }
}
