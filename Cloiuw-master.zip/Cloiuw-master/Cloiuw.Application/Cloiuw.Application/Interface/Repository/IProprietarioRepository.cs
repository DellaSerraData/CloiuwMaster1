﻿using Cloiuw.Application.Model.Proprietario;

namespace Cloiuw.Application.Interface.Repository
{
    public interface IProprietarioRepository
    {
        Task<bool> ProprietarioCadastrado(Guid idProprietario);
        Task<ProprietarioGetModel> ListarInformacoes(Guid idProprietario);
    }
}
