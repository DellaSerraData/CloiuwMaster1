using Cloiuw.Application.Model.Corretor;
using System;
using System.Threading.Tasks;

namespace Cloiuw.Application.Interface.Repository
{
    public interface ICorretoresRepository
    {
        Task<bool> CorretorCadastrado(Guid idCorretor);
        Task<CorretorGetModel> ListarInformacoes(Guid idCorretor);
    }
}
