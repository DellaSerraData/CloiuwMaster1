﻿namespace Cloiuw.Application.Configs
{
    public class DbCloiuwConfig
    {
        public static string DbCloiuwConnectionString { get; set; }
    }
}
