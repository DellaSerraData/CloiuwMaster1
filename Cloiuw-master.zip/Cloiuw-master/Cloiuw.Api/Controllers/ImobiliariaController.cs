using Cloiuw.Application.Interface.Service;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Cloiuw.Api.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [ApiVersion("1.0")]
    [Route("v{version:apiVersion}/imobiliaria")]
    public class ImobiliariaController : ControllerBase
    {
        private readonly IImobiliariaService imobiliariaService;

        /// <summary>
        /// Construtor
        /// </summary>
        /// <param name="imobiliariaService"></param>
        public ImobiliariaController(IImobiliariaService imobiliariaService)
        {
            this.imobiliariaService = imobiliariaService;
        }

        /// <summary>
        /// Listar informa��es da imobili�ria
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("listar-informacoes/{id}")]
        public async Task<IActionResult> ListarInformacoes([FromRoute] string id)
        {
            try
            {
                if (!Guid.TryParse(id, out var idImobiliaria))
                    return BadRequest("Id inv�lido.");

                var response = await imobiliariaService.ListarInformacoes(idImobiliaria);

                return Ok(response);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }
    }
}
