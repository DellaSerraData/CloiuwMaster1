using Cloiuw.Application.Interface.Service;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Cloiuw.Api.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [ApiVersion("1.0")]
    [Route("v{version:apiVersion}/locadores")]
    public class LocadoresController : ControllerBase
    {
        private readonly ILocadoresService locadoresService;

        /// <summary>
        /// Construtor
        /// </summary>
        /// <param name="locadoresService"></param>
        public LocadoresController(ILocadoresService locadoresService)
        {
            this.locadoresService = locadoresService;
        }

        /// <summary>
        /// Listar informa��es dos locadores
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("listar-informacoes/{id}")]
        public async Task<IActionResult> ListarInformacoes([FromRoute] string id)
        {
            try
            {
                if (!Guid.TryParse(id, out var idLocador))
                    return BadRequest("Id inv�lido.");

                var response = await locadoresService.ListarInformacoes(idLocador);

                return Ok(response);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }
    }
}
