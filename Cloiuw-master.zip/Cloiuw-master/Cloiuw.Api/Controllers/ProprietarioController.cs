﻿using Cloiuw.Application.Interface.Service;
using Microsoft.AspNetCore.Mvc;

namespace Cloiuw.Api.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [ApiVersion("1.0")]
    [Route("v{version:apiVersion}/proprietario")]
    public class ProprietarioController : ControllerBase
    {
        private readonly IProprietarioService proprietarioService;
        /// <summary>
        /// Construtor
        /// </summary>
        /// <param name="proprietarioService"></param>
        public ProprietarioController(IProprietarioService proprietarioService)
        {
            this.proprietarioService = proprietarioService;
        }

        /// <summary>
        /// Listar informações do proprietario
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("listar-informacoes/{id}")]
        public async Task<IActionResult> ListarInformacoes([FromRoute]string id)
        {
            try
            {
                if (!Guid.TryParse(id, out var idProprietario))
                    return BadRequest("Id inválido.");

                var response = await proprietarioService.ListarInformacoes(idProprietario);

                return Ok(response);
            }catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }
    }
}
