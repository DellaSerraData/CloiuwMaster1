using Cloiuw.Application.Interface.Service;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Cloiuw.Api.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [ApiVersion("1.0")]
    [Route("v{version:apiVersion}/corretor")]
    public class CorretoresController : ControllerBase
    {
        private readonly ICorretorService corretorService;

        /// <summary>
        /// Construtor
        /// </summary>
        /// <param name="corretorService"></param>
        public CorretoresController(ICorretorService corretorService)
        {
            this.corretorService = corretorService;
        }

        /// <summary>
        /// Listar informa��es do corretor
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("listar-informacoes/{id}")]
        public async Task<IActionResult> ListarInformacoes([FromRoute] string id)
        {
            try
            {
                if (!Guid.TryParse(id, out var idCorretor))
                    return BadRequest("Id inv�lido.");

                var response = await corretorService.ListarInformacoes(idCorretor);

                return Ok(response);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }
    }
}
